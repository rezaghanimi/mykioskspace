Virtual Keyboard for Google Chrome&trade;
=========================================

Virtual Keyboard for Google Chrome&trade; will popup automatically when the user clicks on an input field such as textboxes and textareas. Futhermore, the keyboard will disappear automatically once no longer needed.

This extension is ideal for touch screen devices. This keyboard works like an iOS/Android/Windows 8 touch virtual keyboard.

<img src="http://xontab.azurewebsites.net/Content/VirtualKeyboard/1.png" alt="" />

For more details visit: http://xontab.com/Apps/VirtualKeyboard/
